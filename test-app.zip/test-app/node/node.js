const express = require('express');
const  http =require('http');
const cors = require('cors');
const hostname='0.0.0.0';
const port=3000;
const mongoose = require('mongoose');
const app=express();
var mqtt = require('mqtt')
var client  = mqtt.connect('mqtt://broker.hivemq.com')  
let socketIO = require('socket.io');
const sensors = require('./models/sensors');
const sensorRouter = require('./routes/sensorRouter');
const connect =mongoose.connect('mongodb://localhost:27017/mask');
 connect.then((db) => {
  const connect = mongoose.connect('mongodb://localhost:27017/mask');
    console.log("Connected correctly to server");
  })
app.use(cors({ origin: 'http://localhost:4200' }));
app.use('/sensors',sensorRouter);
const server = http.createServer(app);
let io = socketIO(server);
require('events').EventEmitter.defaultMaxListeners = 0

 var message= "";
client.on('connect',()=>{
  io.on('connection', (socket) => {
    console.log('user connected');

    socket.on('new-message', (message) => {

       console.log(message);
      client.publish('action',message.toString())

		
    });
});

})


client.on('connect',()=>{
  client.subscribe('&1230detect1230&cozzz');

})
client.on('message', (topic, message)=> {
    // message is Buffer
    msg=message.toString()
    msg1={label:msg}
          connect.then((db) => {
    
            console.log('inserted correctly to database');
          
            var newSensor = sensors(msg1);
          
            newSensor.save()
                .then((sensor) => {
                    console.log(sensor);
          
                    
                  })
               
                .catch((err) => {
                    console.log(err);
                });
          
          });

     
     message1=message.toString();
     io.on('connection', (socket) => {
  
          io.emit('new-message1',message1);  
      
  });          
  })

server.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
  });