const mongoose=require('mongoose');
const Schema=mongoose.Schema;

var sensorSchema=new Schema ({      
  label:{
    type:String
    },
},{
    timestamps:true
})  ;
var sensors=mongoose.model('sensor',sensorSchema);

module.exports=sensors;