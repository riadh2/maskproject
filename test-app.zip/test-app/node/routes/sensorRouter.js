const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const sensors = require('../models/sensors');   
    

const sensorRouter = express.Router();
sensorRouter.use(bodyParser.json());
sensorRouter.route('/')

.get((req,res,next) => {
    sensors.find({})
    .then((sensors) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(sensors);
    }, (err) => next(err))
    .catch((err) => next(err));
})
.post((req, res, next) => {
    sensors.create(req.body)
    .then((sensor) => {
        console.log('sensor  added ',sensor);
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(sensor);
    }, (err) => next(err))
    .catch((err) => next(err));
})
.put((req, res, next) => {
    res.statusCode = 403;
    res.end('PUT operation not supported on /gases');
})
.delete((req, res, next) => {
    sensors.remove({})
    .then((response) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(response);
    }, (err) => next(err))
    .catch((err) => next(err));    
});


sensorRouter.route('/:sensorId')

.get((req,res,next) => {
    sensors.findById(req.params.sensorId)
    .then((sensor) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(sensor);
    }, (err) => next(err))
    .catch((err) => next(err));
})
.post((req, res, next) => {
    res.statusCode = 403;
    res.end('POST operation not supported on /sensors/'+ req.params.sensorId);
})
.put((req, res, next) => {
    sensors.findByIdAndUpdate(req.params.sensorId, {
        $set: req.body
    }, { new: true })
    .then((sensor) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(sensor);
    }, (err) => next(err))
    .catch((err) => next(err)); 
})
.delete((req, res, next) => {
    sensors.findByIdAndRemove(req.params.sensorId)
    .then((resp) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(resp);
    }, (err) => next(err))
    .catch((err) => next(err));
});


module.exports = sensorRouter;